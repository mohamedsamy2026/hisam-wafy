




//التكليف 01
/*
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Learn JavaScript</title>
    // <script>
    //   // Code One
    //   document.getElementById("el").style.color = "red";
    // </script>
    // <script>
    //   // Code Two
    //   window.onload = function () {
    //     document.getElementById("el").style.color = "red";
    //   };
    // </script>
  </head>
  <body>
    <h1 id="el">Page Title</h1>
    // <script>
    //   // Code Three
    //   document.getElementById("el").style.color = "red";
    // </script>
  </body>
</html>

//Answer
/*
"code One" doesnot work why?
because it runs before the element is created
*/ 

// window.onload = function () {
// console.log(document.getElementById("Elzero"));
//   };
